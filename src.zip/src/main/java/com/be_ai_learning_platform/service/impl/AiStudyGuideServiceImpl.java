package com.be_ai_learning_platform.service.impl;

import com.be_ai_learning_platform.AI.GeminiResponsesClient;
import com.be_ai_learning_platform.service.AiStudyGuideService;
import org.springframework.stereotype.Service;

import java.util.Locale;

@Service
public class AiStudyGuideServiceImpl implements AiStudyGuideService {

    private static final int MAX_STUDY_GUIDE_CHARS = 9000;

    private final GeminiResponsesClient responsesClient;

    public AiStudyGuideServiceImpl(GeminiResponsesClient responsesClient) {
        this.responsesClient = responsesClient;
    }

    @Override
    public String generateStudyGuide(String userFullName, String userResultJson) {
        String name = (userFullName == null || userFullName.isBlank()) ? "bạn" : userFullName.trim();
        String json = (userResultJson == null) ? "" : userResultJson.trim();

        String prompt = buildStudyGuidePrompt(name, json);

        String raw = "";
        try {
            raw = responsesClient.generateText(prompt);
        } catch (Exception ignore) {
        }

        raw = safeTrim(raw, MAX_STUDY_GUIDE_CHARS);
        raw = stripBackticks(raw);

        // Must-have header
        if (!containsIgnoreCase(raw, "Gợi ý ôn tập:")) {
            // một số model hay trả về thiếu label -> wrap lại
            raw = ("Gợi ý ôn tập:\n" + raw).trim();
        }

        // Cấm placeholder lộ
        if (containsPlaceholder(raw)) {
            return fallbackStudyGuide(userFullName);
        }

        // Nếu quá ngắn -> fallback
        if (raw.isBlank() || raw.length() < 200) {
            return fallbackStudyGuide(userFullName);
        }

        return raw.trim();
    }

    @Override
    public String fallbackStudyGuide(String userFullName) {
        String name = (userFullName == null || userFullName.isBlank()) ? "bạn" : userFullName.trim();

        return ("""
Gợi ý ôn tập:
Tiêu đề: Hướng dẫn ôn tập cá nhân hóa
Môn học: Lập trình
Chủ đề: Ôn theo câu sai
Tóm tắt: Bạn đã hoàn thành bài và có những câu làm đúng, cho thấy bạn đã nắm được một phần kiến thức nền. Tuy nhiên, các câu làm sai đang chỉ ra một số lỗ hổng về khái niệm trọng tâm hoặc cách áp dụng vào tình huống cụ thể. Hãy ưu tiên xem lại từng câu sai, xác định vì sao bạn chọn/viết như vậy, rồi đối chiếu với đáp án đúng và phần giải thích. Nếu là câu kỹ thuật/code, hãy luyện lại bằng một ví dụ ngắn của chính bạn để “khóa” kiến thức. Bạn đang đi đúng hướng — chỉ cần ôn đúng trọng điểm và luyện thêm 1–2 vòng retest là điểm sẽ cải thiện rõ.

Gợi ý ôn tập:
- Mở “Xem lại đáp án”, liệt kê 3 câu sai quan trọng nhất và ghi rõ: sai do hiểu khái niệm hay sai do đọc đề/nhầm lựa chọn.
- Với mỗi câu sai, viết 1 “quy tắc kiểm tra nhanh” (1 dòng) để lần sau tránh lặp lại lỗi.
- Tạo 1 ví dụ nhỏ (hoặc 5 dòng giải thích) áp dụng đúng khái niệm của mỗi câu sai; tự giải lại không nhìn đáp án.
- Ôn lại phần từ vựng/thuật ngữ trong bài (6–10 từ) và tự đặt 1 câu dùng đúng thuật ngữ đó.
- Làm retest sau cooldown: đặt mục tiêu tăng ít nhất +10 điểm và so sánh lỗi còn lặp lại để xử lý tiếp.

Các khái niệm chính:
Ôn theo câu sai: Tập trung vào lý do sai và quy tắc tránh sai giúp tiến bộ nhanh hơn so với đọc lại toàn bộ.
Quy tắc kiểm tra nhanh: Một checklist 1 dòng (vd: “đọc kỹ điều kiện”, “so sánh A/B”, “xác định input/output”) để giảm lỗi chủ quan.
Ví dụ tối thiểu: Tự tạo 1 ví dụ ngắn để kiểm tra mình thật sự hiểu (giống như test case nhỏ).
Rà soát từ khoá: Xác định các từ khoá quyết định đáp án/ý đúng và đối chiếu với câu trả lời của mình.

Danh sách từ vựng:
keyword: Từ khóa quan trọng quyết định ý đúng.
distractor: Phương án gây nhiễu dễ khiến chọn nhầm.
rubric: Tiêu chí chấm điểm/tiêu chí đánh giá (đặc biệt với tự luận).
analysis: Phân tích/giải thích lý do đúng-sai.
constraint: Ràng buộc/điều kiện giới hạn trong đề bài.
edge case: Trường hợp biên dễ bị bỏ sót.

Câu hỏi ôn tập:
- Ở câu sai nhiều nhất, từ khóa nào trong đề bạn đã bỏ sót?
- Nếu phải giải lại câu đó, bạn sẽ kiểm tra điều gì trước tiên?
- Khái niệm cốt lõi đứng sau câu sai là gì? Hãy giải thích lại bằng 2–3 câu.
- Bạn có thể tự tạo 1 ví dụ (hoặc tình huống) để chứng minh đáp án đúng không?
- Lỗi sai của bạn thuộc loại nào: hiểu sai khái niệm, đọc đề vội, hay nhầm lựa chọn?
- Nếu gặp câu tương tự, bạn sẽ dùng “quy tắc kiểm tra nhanh” nào?
- Bạn sẽ ôn lại phần nào trong 15 phút tới để cải thiện điểm nhanh nhất?
""".formatted(name)).trim();
    }

    private String buildStudyGuidePrompt(String name, String userResultJson) {
        // Prompt “study guide” riêng: cho phép chi tiết hơn và có cấu trúc ổn định để FE render.
        return ("""
Bạn là một trợ giảng AI chuyên nghiệp, tận tâm và có kiến thức sâu rộng về lĩnh vực lập trình và công nghệ ở cấp độ đại học.

NHIỆM VỤ:
Dựa trên dữ liệu kết quả bài kiểm tra (Quiz) của học viên ở dạng JSON bên dưới, hãy phân tích và tạo ra một "Tài liệu Hướng dẫn ôn tập cá nhân hóa" giúp học viên hiểu vì sao đúng/sai và có kế hoạch cải thiện rõ ràng.

YÊU CẦU QUAN TRỌNG:
- BẮT ĐẦU bằng đúng 1 câu chào: "Chào %s,"
- Sau đó CHỈ trả về đúng khối bên dưới theo đúng tiêu đề và thứ tự. KHÔNG thêm mục khác.

ĐỊNH DẠNG BẮT BUỘC (giữ nguyên tiêu đề, giữ đúng dấu ":" sau tiêu đề):
Gợi ý ôn tập:
Tiêu đề: <tối đa 12 từ, nêu đúng nội dung bài>
Môn học: <tên môn>
Chủ đề: <tên chủ đề>
Tóm tắt: <1 đoạn 100–150 từ>

Gợi ý ôn tập:
- <bước 1: cụ thể, có hành động, có mục tiêu>
- <bước 2: cụ thể, có hành động, có mục tiêu>
- <bước 3: cụ thể, có hành động, có mục tiêu>
- <bước 4: cụ thể, có hành động, có mục tiêu>
- <bước 5: cụ thể, có hành động, có mục tiêu>

Các khái niệm chính:
<Khái niệm 1>: <giải thích chi tiết, ngắn gọn, dễ hiểu; nếu là code/kỹ thuật thì kèm ví dụ minh hoạ ngắn hoặc so sánh>
<Khái niệm 2>: <...>
<Khái niệm 3>: <...>
<Khái niệm 4>: <...>

Danh sách từ vựng:
<Từ khóa 1>: <định nghĩa ngắn gọn>
<Từ khóa 2>: <định nghĩa ngắn gọn>
<Từ khóa 3>: <định nghĩa ngắn gọn>
<Từ khóa 4>: <định nghĩa ngắn gọn>

Câu hỏi ôn tập:
- <câu hỏi 1>
- <câu hỏi 2>
- <câu hỏi 3>
- <câu hỏi 4>
- <câu hỏi 5>
- <câu hỏi 6>
- <câu hỏi 7>

QUY TẮC BẮT BUỘC:
- KHÔNG được dùng placeholder như "...", "…", "(Chưa có)", "(Chưa xác định)".
- Dùng tiếng Việt tự nhiên, giọng văn khích lệ và mang tính xây dựng.
- Tóm tắt (100–150 từ): khen những câu đúng (isCorrect=true), chỉ ra lỗ hổng từ câu sai (isCorrect=false). Không bịa thêm câu hỏi/kiến thức ngoài JSON.
- "Gợi ý ôn tập" phải có đúng 5 bullet "- " và mỗi bullet phải là hành động cụ thể (đọc gì, làm gì, viết gì, kiểm tra gì).
- "Các khái niệm chính" tối thiểu 4 khái niệm; ƯU TIÊN giải thích kỹ các khái niệm liên quan đến câu sai. Nếu có nhiều câu sai, có thể tăng lên 6–8 khái niệm.
- "Danh sách từ vựng" tối thiểu 6 thuật ngữ chuyên ngành xuất hiện trong bài quiz (nếu thiếu, chọn các thuật ngữ cốt lõi từ nội dung câu hỏi/đáp án).
- "Câu hỏi ôn tập" bắt buộc đúng 7 câu, mỗi câu 1 bullet.
- Tuyệt đối KHÔNG dùng ký tự backtick: `
- Không markdown, không in đậm, không đánh số.

DỮ LIỆU ĐẦU VÀO (JSON):
%s
""".formatted(name, userResultJson == null ? "" : userResultJson)).trim();
    }

    private String safeTrim(String s, int max) {
        if (s == null) return "";
        String t = s.trim();
        if (t.length() <= max) return t;
        return t.substring(0, max).trim();
    }

    private String stripBackticks(String s) {
        if (s == null) return "";
        return s.replace("`", "").trim();
    }

    private boolean containsIgnoreCase(String text, String needle) {
        if (text == null || needle == null) return false;
        return text.toLowerCase(Locale.ROOT).contains(needle.toLowerCase(Locale.ROOT));
    }

    private boolean containsPlaceholder(String text) {
        if (text == null) return false;
        return text.contains("...") || text.contains("…") || text.contains("(Chưa có)") || text.contains("(Chưa xác định)");
    }
}